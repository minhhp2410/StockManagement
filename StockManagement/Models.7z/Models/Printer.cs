﻿namespace BC_gen
{
    using System;
    using System.IO;
    using System.Runtime.InteropServices;

    /// <summary>
    /// Defines the <see cref="Printer" />.
    /// </summary>
    class Printer
    {
        /// <summary>
        /// Defines the <see cref="DOCINFOA" />.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public class DOCINFOA
        {
            /// <summary>
            /// Defines the pDocName.
            /// </summary>
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDocName;

            /// <summary>
            /// Defines the pOutputFile.
            /// </summary>
            [MarshalAs(UnmanagedType.LPStr)]
            public string pOutputFile;

            /// <summary>
            /// Defines the pDataType.
            /// </summary>
            [MarshalAs(UnmanagedType.LPStr)]
            public string pDataType;
        }

        /// <summary>
        /// The OpenPrinter.
        /// </summary>
        /// <param name="szPrinter">The szPrinter<see cref="string"/>.</param>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <param name="pd">The pd<see cref="IntPtr"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);

        /// <summary>
        /// The ClosePrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool ClosePrinter(IntPtr hPrinter);

        /// <summary>
        /// The StartDocPrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <param name="level">The level<see cref="Int32"/>.</param>
        /// <param name="di">The di<see cref="DOCINFOA"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Unicode, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartDocPrinter(IntPtr hPrinter, Int32 level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);

        /// <summary>
        /// The EndDocPrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndDocPrinter(IntPtr hPrinter);

        /// <summary>
        /// The StartPagePrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool StartPagePrinter(IntPtr hPrinter);

        /// <summary>
        /// The EndPagePrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool EndPagePrinter(IntPtr hPrinter);

        /// <summary>
        /// The WritePrinter.
        /// </summary>
        /// <param name="hPrinter">The hPrinter<see cref="IntPtr"/>.</param>
        /// <param name="pBytes">The pBytes<see cref="IntPtr"/>.</param>
        /// <param name="dwCount">The dwCount<see cref="Int32"/>.</param>
        /// <param name="dwWritten">The dwWritten<see cref="Int32"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
        public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, Int32 dwCount, out Int32 dwWritten);

        /// <summary>
        /// The SendBytesToPrinter.
        /// </summary>
        /// <param name="szPrinterName">The szPrinterName<see cref="string"/>.</param>
        /// <param name="pBytes">The pBytes<see cref="IntPtr"/>.</param>
        /// <param name="dwCount">The dwCount<see cref="Int32"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        public static bool SendBytesToPrinter(string szPrinterName, IntPtr pBytes, Int32 dwCount)
        {
            Int32 dwError = 0, dwWritten = 0;
            IntPtr hPrinter = new IntPtr(0);
            DOCINFOA di = new DOCINFOA();
            bool bSuccess = false; // Assume failure unless you specifically succeed.

            di.pDocName = "RAW Document";
            // Win7
            di.pDataType = "RAW";

            // Win8+
            // di.pDataType = "XPS_PASS";

            // Open the printer.
            if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero))
            {
                // Start a document.
                if (StartDocPrinter(hPrinter, 1, di))
                {
                    // Start a page.
                    if (StartPagePrinter(hPrinter))
                    {
                        // Write your bytes.
                        bSuccess = WritePrinter(hPrinter, pBytes, dwCount, out dwWritten);
                        EndPagePrinter(hPrinter);
                    }
                    EndDocPrinter(hPrinter);
                }
                ClosePrinter(hPrinter);
            }
            // If you did not succeed, GetLastError may give more information
            // about why not.
            if (bSuccess == false)
            {
                dwError = Marshal.GetLastWin32Error();
            }
            return bSuccess;
        }

        /// <summary>
        /// The SendFileToPrinter.
        /// </summary>
        /// <param name="szPrinterName">The szPrinterName<see cref="string"/>.</param>
        /// <param name="szFileName">The szFileName<see cref="string"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        public static bool SendFileToPrinter(string szPrinterName, string szFileName)
        {
            // Open the file.
            FileStream fs = new FileStream(szFileName, FileMode.Open);
            // Create a BinaryReader on the file.
            BinaryReader br = new BinaryReader(fs);
            // Dim an array of bytes big enough to hold the file's contents.
            Byte[] bytes = new Byte[fs.Length];
            bool bSuccess = false;
            // Your unmanaged pointer.
            IntPtr pUnmanagedBytes = new IntPtr(0);
            int nLength;

            nLength = Convert.ToInt32(fs.Length);
            // Read the contents of the file into the array.
            bytes = br.ReadBytes(nLength);
            // Allocate some unmanaged memory for those bytes.
            pUnmanagedBytes = Marshal.AllocCoTaskMem(nLength);
            // Copy the managed byte array into the unmanaged array.
            Marshal.Copy(bytes, 0, pUnmanagedBytes, nLength);
            // Send the unmanaged bytes to the printer.
            bSuccess = SendBytesToPrinter(szPrinterName, pUnmanagedBytes, nLength);
            // Free the unmanaged memory that you allocated earlier.
            Marshal.FreeCoTaskMem(pUnmanagedBytes);
            fs.Close();
            fs.Dispose();
            fs = null;
            return bSuccess;
        }

        /// <summary>
        /// The SendStringToPrinter.
        /// </summary>
        /// <param name="szPrinterName">The szPrinterName<see cref="string"/>.</param>
        /// <param name="szString">The szString<see cref="string"/>.</param>
        /// <returns>The <see cref="bool"/>.</returns>
        public static bool SendStringToPrinter(string szPrinterName, string szString)
        {
            IntPtr pBytes;
            Int32 dwCount;
            // How many characters are in the string?
            dwCount = szString.Length;
            // Assume that the printer is expecting ANSI text, and then convert
            // the string to ANSI text.
            pBytes = Marshal.StringToCoTaskMemAnsi(szString);
            // Send the converted ANSI string to the printer.
            SendBytesToPrinter(szPrinterName, pBytes, dwCount);
            Marshal.FreeCoTaskMem(pBytes);
            return true;
        }
    }
}
